'use client'

import { FormEvent, useState } from 'react'
import { ArrowRight, LockKeyhole, UserPlus } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

export default function AuthPage() {
  const supabase = createClient()
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [form, setForm] = useState({ email: '', password: '' })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(event: FormEvent) {
    event.preventDefault()
    setLoading(true)
    setMessage('')
    setError('')

    if (mode === 'signin') {
      const { error: signInError } = await supabase.auth.signInWithPassword(form)
      if (signInError) setError('Invalid email or password.')
      else window.location.href = '/admin'
    } else {
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL ?? `${window.location.origin}/auth/callback`,
        },
      })
      if (signUpError) setError(signUpError.message.includes('Password') ? signUpError.message : 'We could not create your account. Please check your details and try again.')
      else if (data.session) window.location.href = '/admin'
      else setMessage('Account created. Check your email to confirm your account, then sign in.')
    }
    setLoading(false)
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f7faff] px-6 py-12 text-slate-950">
      <section className="w-full max-w-md rounded-[2rem] border border-blue-100 bg-white p-7 shadow-xl shadow-blue-900/10 sm:p-9">
        <a href="/" className="flex items-center gap-3">
          <span className="flex size-11 items-center justify-center rounded-xl bg-[#0A4DC0] font-black text-white">R1</span>
          <div><p className="font-black">R1 JOB</p><p className="text-sm text-slate-500">Bridging talents and opportunities</p></div>
        </a>
        <div className="mt-8 flex rounded-xl bg-blue-50 p-1" role="tablist" aria-label="Account access">
          <button type="button" role="tab" aria-selected={mode === 'signin'} onClick={() => setMode('signin')} className={`flex-1 rounded-lg px-3 py-2.5 text-sm font-bold ${mode === 'signin' ? 'bg-white text-[#0A4DC0] shadow-sm' : 'text-slate-500'}`}><LockKeyhole className="mr-2 inline size-4" />Log in</button>
          <button type="button" role="tab" aria-selected={mode === 'signup'} onClick={() => setMode('signup')} className={`flex-1 rounded-lg px-3 py-2.5 text-sm font-bold ${mode === 'signup' ? 'bg-white text-[#0A4DC0] shadow-sm' : 'text-slate-500'}`}><UserPlus className="mr-2 inline size-4" />Sign up</button>
        </div>
        <h1 className="mt-8 text-3xl font-black tracking-tight">{mode === 'signin' ? 'Welcome back' : 'Create your account'}</h1>
        <p className="mt-2 text-sm leading-6 text-slate-500">{mode === 'signin' ? 'Log in to access the private jobs publishing portal.' : 'Create an account to get started with R1 JOB.'}</p>
        <form onSubmit={submit} className="mt-7 flex flex-col gap-4">
          <label className="flex flex-col gap-2 text-sm font-semibold">Email address<input required type="email" autoComplete="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} className="rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" placeholder="you@example.com" /></label>
          <label className="flex flex-col gap-2 text-sm font-semibold">Password<input required minLength={6} type="password" autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} className="rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" placeholder="At least 6 characters" /></label>
          <button disabled={loading} className="mt-2 inline-flex items-center justify-center rounded-xl bg-[#0A4DC0] py-3.5 font-bold text-white transition-colors hover:bg-blue-800 disabled:opacity-60">{loading ? 'Please wait...' : mode === 'signin' ? 'Log in securely' : 'Create account'}{!loading && <ArrowRight className="ml-2 size-4" />}</button>
        </form>
        {message && <p className="mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">{message}</p>}
        {error && <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm font-semibold text-rose-600">{error}</p>}
        <p className="mt-6 text-center text-xs leading-5 text-slate-400">Admin access is granted separately. Creating an account does not automatically grant publishing permissions.</p>
      </section>
    </main>
  )
}
