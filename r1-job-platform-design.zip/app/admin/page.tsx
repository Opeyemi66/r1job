'use client'

export const dynamic = 'force-dynamic'

import { FormEvent, useEffect, useState } from 'react'
import { Copy, ExternalLink, LogOut, Plus, ShieldCheck, Trash2 } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'

type Job = { id: string; title: string; company: string; location: string; job_type: string; salary: string; description: string; requirements: string; application_url: string | null; application_email: string | null; application_phone: string | null; published: boolean; created_at: string }

const emptyForm = { title: '', company: '', location: 'Lagos, Nigeria', job_type: 'Full-time', salary: '', description: '', requirements: '', application_url: '', application_email: '', application_phone: '', published: true }

export default function AdminPage() {
  const supabase = createClient()
  const [user, setUser] = useState<any>(null)
  const [admin, setAdmin] = useState(false)
  const [jobs, setJobs] = useState<Job[]>([])
  const [form, setForm] = useState(emptyForm)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState('')
  const [login, setLogin] = useState({ email: '', password: '' })

  async function load() {
    setLoading(true)
    const { data: { user: currentUser } } = await supabase.auth.getUser()
    setUser(currentUser)
    if (currentUser) {
      const { data: access } = await supabase.from('admin_users').select('user_id').eq('user_id', currentUser.id).maybeSingle()
      setAdmin(Boolean(access))
      if (access) {
        const { data } = await supabase.from('jobs').select('id,title,company,location,job_type,salary,description,requirements,application_url,application_email,application_phone,published,created_at').order('created_at', { ascending: false })
        setJobs((data as Job[]) ?? [])
      }
    }
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function signIn(e: FormEvent) {
    e.preventDefault(); setMessage('')
    const { error } = await supabase.auth.signInWithPassword(login)
    if (error) setMessage('Invalid email or password.')
    else await load()
  }

  async function createJob(e: FormEvent) {
    e.preventDefault(); setSaving(true); setMessage('')
    const { data, error } = await supabase.from('jobs').insert({ ...form, application_url: form.application_url || null, application_email: form.application_email || null, application_phone: form.application_phone || null, created_by: user.id }).select('id,title,company,location,job_type,salary,description,requirements,application_url,application_email,application_phone,published,created_at').single()
    if (error) setMessage('Could not publish this job. Check the required fields and try again.')
    else { setJobs((current) => [data as Job, ...current]); setForm(emptyForm); setMessage('Job published successfully.') }
    setSaving(false)
  }

  async function deleteJob(id: string) {
    if (!window.confirm('Remove this job from the website?')) return
    const { error } = await supabase.from('jobs').delete().eq('id', id)
    if (!error) setJobs((current) => current.filter((job) => job.id !== id))
  }

  function copyLink(id: string) {
    navigator.clipboard.writeText(`${window.location.origin}/jobs/${id}`)
    setMessage('Share link copied to clipboard.')
  }

  if (loading) return <main className="flex min-h-screen items-center justify-center bg-slate-50 text-slate-600">Loading secure portal...</main>
  if (!user) return <main className="flex min-h-screen items-center justify-center bg-[#f7faff] px-6"><form onSubmit={signIn} className="w-full max-w-md rounded-3xl border border-blue-100 bg-white p-8 shadow-xl"><div className="mb-8 flex items-center gap-3"><span className="flex size-11 items-center justify-center rounded-xl bg-[#0A4DC0] font-black text-white">R1</span><div><p className="font-black text-slate-950">R1 JOB</p><p className="text-sm text-slate-500">Private admin portal</p></div></div><h1 className="text-3xl font-black tracking-tight text-slate-950">Welcome back</h1><p className="mt-2 text-sm text-slate-500">Sign in to publish and manage opportunities.</p><div className="mt-7 flex flex-col gap-4"><input required type="email" placeholder="Admin email" value={login.email} onChange={(e) => setLogin({ ...login, email: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" /><input required type="password" placeholder="Password" value={login.password} onChange={(e) => setLogin({ ...login, password: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" /><button className="rounded-xl bg-[#0A4DC0] py-3.5 font-bold text-white">Sign in securely</button></div>{message && <p className="mt-4 text-sm font-semibold text-rose-600">{message}</p>}</form></main>
  if (!admin) return <main className="flex min-h-screen items-center justify-center bg-slate-50 px-6"><div className="max-w-md rounded-3xl border border-amber-200 bg-white p-8 text-center shadow-xl"><ShieldCheck className="mx-auto size-10 text-amber-500" /><h1 className="mt-5 text-2xl font-black text-slate-950">Access pending</h1><p className="mt-3 text-slate-600">This account is signed in, but it has not been added to the R1 JOB admin allowlist yet.</p><button onClick={() => supabase.auth.signOut()} className="mt-6 inline-flex items-center gap-2 font-bold text-[#0A4DC0]">Sign out <LogOut className="size-4" /></button></div></main>

  return <main className="min-h-screen bg-[#f7faff] text-slate-950"><header className="border-b border-slate-200 bg-white"><div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5"><div className="flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-xl bg-[#0A4DC0] font-black text-white">R1</span><div><p className="font-black">Jobs manager</p><p className="text-xs text-slate-500">Private publishing portal</p></div></div><button onClick={() => supabase.auth.signOut().then(load)} className="inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-[#0A4DC0]">Sign out <LogOut className="size-4" /></button></div></header><div className="mx-auto grid max-w-7xl gap-8 px-6 py-10 lg:grid-cols-[.8fr_1.2fr]"><section className="rounded-3xl border border-blue-100 bg-white p-6 shadow-sm"><div className="flex items-center gap-3"><Plus className="size-5 text-[#0A4DC0]" /><div><h1 className="text-xl font-black">Add a new job</h1><p className="text-sm text-slate-500">Publish an opportunity to the public website.</p></div></div><form onSubmit={createJob} className="mt-6 flex flex-col gap-3">{[['title','Job title'],['company','Company'],['location','Location'],['job_type','Job type'],['salary','Salary'],['application_url','Google Form or application link (optional)'],['application_email','Application email (optional)'],['application_phone','Application phone (optional)']].map(([key, label]) => <input key={key} required={!['application_url','application_email','application_phone'].includes(key)} placeholder={label} value={(form as any)[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} className="rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" />)}<p className="text-xs leading-5 text-slate-500">Add one or more application options. Visitors will see the matching Apply button on the job page.</p><textarea required placeholder="Job description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="min-h-28 rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" /><textarea placeholder="Requirements" value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} className="min-h-24 rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-[#0A4DC0]" /><button disabled={saving} className="rounded-xl bg-[#0A4DC0] py-3.5 font-bold text-white disabled:opacity-60">{saving ? 'Publishing...' : 'Publish job'}</button>{message && <p className="text-sm font-semibold text-[#0A4DC0]">{message}</p>}</form></section><section><div className="mb-5 flex items-end justify-between"><div><p className="text-sm font-bold uppercase tracking-[0.15em] text-[#0A4DC0]">Content library</p><h2 className="mt-2 text-3xl font-black">Published jobs <span className="text-slate-300">{jobs.length}</span></h2></div><a href="/" target="_blank" className="inline-flex items-center gap-2 text-sm font-bold text-[#0A4DC0]">View website <ExternalLink className="size-4" /></a></div><div className="flex flex-col gap-3">{jobs.map((job) => <article key={job.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-4"><div><h3 className="font-bold text-slate-950">{job.title}</h3><p className="mt-1 text-sm text-slate-500">{job.company} · {job.location} · {job.salary}</p></div><span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">{job.published ? 'Live' : 'Draft'}</span></div><div className="mt-4 flex flex-wrap gap-2"><button onClick={() => copyLink(job.id)} className="inline-flex items-center gap-2 rounded-full bg-blue-50 px-3 py-2 text-xs font-bold text-[#0A4DC0]"><Copy className="size-3.5" />Copy share link</button><button onClick={() => deleteJob(job.id)} className="inline-flex items-center gap-2 rounded-full bg-rose-50 px-3 py-2 text-xs font-bold text-rose-600"><Trash2 className="size-3.5" />Delete</button></div></article>)}{jobs.length === 0 && <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500">No jobs yet. Publish your first opportunity.</div>}</div></section></div></main>
}
